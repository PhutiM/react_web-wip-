Run the below to add packages

npm install
npm install react-bootstrap-table
npm install Axios
npm install react-datepicker
npm install react-picky

To sart the project run 

npm start