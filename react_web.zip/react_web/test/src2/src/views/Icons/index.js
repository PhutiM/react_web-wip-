import CoreUIIcons from './CoreUIIcons';
import Flags from './Flags';
import FontAwesome from './FontAwesome';
import SimpleLineIcons from './SimpleLineIcons';

export {
  CoreUIIcons, Flags, FontAwesome, SimpleLineIcons
};
