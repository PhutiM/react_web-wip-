import { Bar, Line } from 'react-chartjs-2';
import React from 'react';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities'
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';

const LineChart = ({details}) => {

    const brandPrimary = getStyle('--primary')
    const brandSuccess = getStyle('--success')
    const brandInfo = getStyle('--warning')
    const brandWarning = getStyle('--warning')
    const brandDanger = getStyle('--danger')
    

    const mainChart = {
         labels: details.map(product => product.product_desc),

        datasets: [
          {
            label: '',
            borderColor: brandPrimary,
            pointHoverBackgroundColor: '#fff',
            borderWidth: 2,
            data: details.map(product => product.value),
          },
         ],
        }    

      const mainChartOpts = {
      tooltips: {
      enabled: false,
      custom: CustomTooltips,
      intersect: true,
      mode: 'index',
      position: 'average',
      callbacks: {
        labelColor: function(tooltipItem, chart) {
          return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor }
        }
      }
      },
      maintainAspectRatio: false,
      legend: {
      display: false,
      },
      scales: {
        xAxes: [
          {
            gridLines: {
              color: 'transparent',
              zeroLineColor: 'transparent',
            },
            ticks: {
              fontSize: 2,
              fontColor: 'transparent',
            },
    
          }],
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            maxTicksLimit: 5,
            stepSize: Math.ceil(25000 / 5),
            max: 25000,
          },
        }],
      },
      elements: {
        line: {
          tension: 0.00001,
          borderWidth: 1,
        },
        
      point: {
        radius: 2,
        hitRadius: 10,
        hoverRadius: 4,
        hoverBorderWidth: 3,
      },
      },
      };

   
return ( 
        <Line data={mainChart} options={mainChartOpts} height={500} />
    )
}

export default LineChart;